const express = require('express');
const indexRoute = require('./api/routes/index')

var path = require('path');

const app = express();


app.use(express.json());

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use('/', indexRoute);


app.listen(4000, () => console.log("server up"));
