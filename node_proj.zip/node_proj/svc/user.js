const db = require('../repository/database');

var ref = db.ref("/user");


module.exports.getUsersList = async function () {
    try {
        userList = await ref.once("value");
        return userList;
    } catch (err) {
        return err;
    }
}

module.exports.createUser = async function (obj) {
    const oneUser = ref.child(obj.id);
    try {
        await oneUser.update(obj);
        return "create";
    } catch (err) {
        return err;
    }

}

module.exports.getUsersById = async function (id) {
    const oneUser = ref.child(id);
    try {
        user = await oneUser.once("value");
        return user;
    } catch (err) {
        return err;
    }
}
