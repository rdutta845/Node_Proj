var express = require('express');
var router = express.Router();
const user = require('../../model/user')

/* GET home page. */
router.get('/', function (req, res, next) {
    console.log("inside");
    res.render('index', { title: 'Orange' });
});
router.get('/getUsers', function (req, res, next) {
    user.get().then((val) => {
        res.json(val);
    })
});
router.get('/getUser/:id', function (req, res, next) {
    user.getById(req.params.id).then((val) => {
        res.json(val);
    })
});
router.post('/createUser', function (req, res, next) {
    user.create(req.body).then((val) => {
        res.status(201);
        res.json(val);
    });
});

module.exports = router;
