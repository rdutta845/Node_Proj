const admin = require('firebase-admin');
const serviceAccount = require('../service-account.json');


admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://user-profile-7b5d7-default-rtdb.firebaseio.com"
});


const db = admin.database();

module.exports = db;
