
Step
    1. npm init
    2. npm install express mongoose 
    3. 
