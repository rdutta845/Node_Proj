const user = require("../svc/user");

// Here, we are implementing the class with Singleton design pattern

class User {
    constructor() {
        if (this.instance) return this.instance;
        User.instance = this;
    }

    get() {
        return user.getUsersList();
    }

    getById(id) {
        return user.getUsersById(id);
    }

    create(data) {
        return user.createUser(data);
    }

    //   delete(id) {
    //     return database.delete("todos", id);
    //   }

    //   update(id, todo) {
    //     return database.set("todos", id, todo);
    //   }
}

module.exports = new User();
